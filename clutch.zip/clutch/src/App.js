import './App.css';
import { Route, Routes } from 'react-router-dom';
import { useEffect } from 'react';
import Footer from "./Components/Footer/Footer"

function App() {
  return (
    <div className="App">
      <Footer/>
    </div>
  );
}

export default App;
