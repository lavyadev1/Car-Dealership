import f1 from "../Assets/f1.png";
import f2 from "../Assets/f2.png";
import f3 from "../Assets/f3.png";

export default{
    f1,
    f2,
    f3,
}