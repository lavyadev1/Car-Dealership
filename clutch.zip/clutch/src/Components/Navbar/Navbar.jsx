import React from 'react'
import './Navbar.scss'

const Navbar = () => {
  return (
    <div>Navbar</div>
  )
}

export default Navbar