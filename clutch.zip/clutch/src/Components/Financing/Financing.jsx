import React from 'react'
import './Financing.scss'

const Financing = () => {
  return (
    <div>Financing</div>
  )
}

export default Financing