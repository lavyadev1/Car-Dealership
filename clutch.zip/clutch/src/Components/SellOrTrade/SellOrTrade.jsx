import React from 'react'
import './SellOrTrade.scss'

const SellOrTrade = () => {
  return (
    <div>SellOrTrade</div>
  )
}

export default SellOrTrade